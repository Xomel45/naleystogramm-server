# naleys-server v0.1.0 — установка на VPS

## Быстрый старт

```bash
# 1. Скопировать бинарь
cp naleys-server /usr/local/bin/
chmod +x /usr/local/bin/naleys-server

# 2. Скопировать конфиг
cp config.json.example /etc/naleys-server.json
# Отредактируйте /etc/naleys-server.json по необходимости

# 3. Создать пользователя (опционально, но рекомендуется)
useradd -r -s /usr/sbin/nologin naleys
mkdir -p /opt/naleys-server
chown naleys:naleys /opt/naleys-server

# 4. Установить systemd-юнит
cp naleys-server.service /etc/systemd/system/
systemctl daemon-reload
systemctl enable --now naleys-server
```

## Режимы запуска

| Команда                           | Назначение                   |
|-----------------------------------|------------------------------|
| `naleys-server --mode discovery`  | Сервер обнаружения (default) |
| `naleys-server --mode group`      | Чат-комната                  |

## Порт

По умолчанию: **47822**
Открыть: `ufw allow 47822/tcp` или `firewall-cmd --add-port=47822/tcp --permanent`

## VPS-ОС

- Этот тариф (gnu):
  **Debian / Ubuntu / AlmaLinux / CentOS / Rocky Linux** (glibc)
